from setuptools import setup, find_packages

setup(
    name='package',
    version='1.0',
    packages=find_packages(),
    package_data={
        'handlers.users': ['__init__.py', 'audio.py', 'balance.py', 'bot_start.py', 'error.py', 'example_voices.py',
                           'instruction.py', 'send_file.py']
    }
)
# запуск python setup.py sdist
