from .users import dp

__all__ = ['dp']  # Список параметров которые можно импортировать из папки handlers