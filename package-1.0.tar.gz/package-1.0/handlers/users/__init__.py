# from .start import dp
from .bot_start import dp
from .instruction import dp
from .example_voices import dp
from .balance import dp
from .audio import dp
from .error import dp


__all__ = ['dp']